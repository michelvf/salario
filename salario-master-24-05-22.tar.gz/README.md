# Calculador de Salario y Tarifa Eléctrica

Calcula el salario descontando 3 % del impuesto por ingresos personales
y el 5% para la Seguridad Social

Calcula la tarifa eléctrica según las tarifas de enero del 2020.

